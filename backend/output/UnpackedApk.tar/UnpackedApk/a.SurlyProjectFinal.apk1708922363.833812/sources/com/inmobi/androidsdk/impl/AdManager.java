package com.inmobi.androidsdk.impl;

public class AdManager {
}
