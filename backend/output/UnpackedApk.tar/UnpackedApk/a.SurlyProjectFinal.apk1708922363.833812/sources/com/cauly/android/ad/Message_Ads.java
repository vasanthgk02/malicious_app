package com.cauly.android.ad;

public class Message_Ads {
    private String C_AD_SHAPE;
    private String C_AD_TYPE;
    private String C_CODE;
    private String C_COLOR;
    private String C_CYCLE;
    private String C_DESCRIPTION;
    private String C_HANDLER;
    private String C_HANDLER_APP_CODE;
    private String C_HANDLER_URL;
    private String C_ID;
    private String C_IMG;
    private String C_ISERIAL;
    private String C_LINK;
    private String C_MARKET;
    private String C_PAY_TYPE;
    private String C_RETCODE;
    private String C_RETMSG;
    private String C_SEND_INFORM;
    private String C_SHAPE_INFO;
    private String C_STRICT_LEVEL;
    private String C_TITLE;

    /* access modifiers changed from: 0000 */
    public String getC_HANDLER() {
        return this.C_HANDLER;
    }

    /* access modifiers changed from: 0000 */
    public void setC_HANDLER(String cHANDLER) {
        this.C_HANDLER = cHANDLER;
    }

    /* access modifiers changed from: 0000 */
    public String getC_HANDLER_URL() {
        return this.C_HANDLER_URL;
    }

    /* access modifiers changed from: 0000 */
    public void setC_HANDLER_URL(String cHANDLERURL) {
        this.C_HANDLER_URL = cHANDLERURL;
    }

    /* access modifiers changed from: 0000 */
    public String getC_HANDLER_APP_CODE() {
        return this.C_HANDLER_APP_CODE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_HANDLER_APP_CODE(String cHANDLERAPPCODE) {
        this.C_HANDLER_APP_CODE = cHANDLERAPPCODE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_PAY_TYPE() {
        return this.C_PAY_TYPE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_PAY_TYPE(String cPAYTYPE) {
        this.C_PAY_TYPE = cPAYTYPE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_AD_TYPE() {
        return this.C_AD_TYPE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_AD_TYPE(String cADTYPE) {
        this.C_AD_TYPE = cADTYPE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_AD_SHAPE() {
        return this.C_AD_SHAPE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_AD_SHAPE(String cADSHAPE) {
        this.C_AD_SHAPE = cADSHAPE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_SHAPE_INFO() {
        return this.C_SHAPE_INFO;
    }

    /* access modifiers changed from: 0000 */
    public void setC_SHAPE_INFO(String cSHAPEINFO) {
        this.C_SHAPE_INFO = cSHAPEINFO;
    }

    /* access modifiers changed from: 0000 */
    public String getC_LINK() {
        return this.C_LINK;
    }

    /* access modifiers changed from: 0000 */
    public void setC_LINK(String cLINK) {
        this.C_LINK = cLINK;
    }

    /* access modifiers changed from: 0000 */
    public String getC_CODE() {
        return this.C_CODE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_CODE(String cCODE) {
        this.C_CODE = cCODE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_ID() {
        return this.C_ID;
    }

    /* access modifiers changed from: 0000 */
    public void setC_ID(String cID) {
        this.C_ID = cID;
    }

    /* access modifiers changed from: 0000 */
    public String getC_TITLE() {
        return this.C_TITLE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_TITLE(String cTITLE) {
        this.C_TITLE = cTITLE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_DESCRIPTION() {
        return this.C_DESCRIPTION;
    }

    /* access modifiers changed from: 0000 */
    public void setC_DESCRIPTION(String cDESCRIPTION) {
        this.C_DESCRIPTION = cDESCRIPTION;
    }

    /* access modifiers changed from: 0000 */
    public String getC_IMG() {
        return this.C_IMG;
    }

    /* access modifiers changed from: 0000 */
    public void setC_IMG(String cIMG) {
        this.C_IMG = cIMG;
    }

    /* access modifiers changed from: 0000 */
    public String getC_MARKET() {
        return this.C_MARKET;
    }

    /* access modifiers changed from: 0000 */
    public void setC_MARKET(String cMARKET) {
        this.C_MARKET = cMARKET;
    }

    /* access modifiers changed from: 0000 */
    public String getC_COLOR() {
        return this.C_COLOR;
    }

    /* access modifiers changed from: 0000 */
    public void setC_COLOR(String cCOLOR) {
        this.C_COLOR = cCOLOR;
    }

    /* access modifiers changed from: 0000 */
    public String getC_ISERIAL() {
        return this.C_ISERIAL;
    }

    /* access modifiers changed from: 0000 */
    public void setC_ISERIAL(String cISERIAL) {
        this.C_ISERIAL = cISERIAL;
    }

    /* access modifiers changed from: 0000 */
    public String getC_RETCODE() {
        return this.C_RETCODE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_RETCODE(String cRETCODE) {
        this.C_RETCODE = cRETCODE;
    }

    /* access modifiers changed from: 0000 */
    public String getC_RETMSG() {
        return this.C_RETMSG;
    }

    /* access modifiers changed from: 0000 */
    public void setC_RETMSG(String cRETMSG) {
        this.C_RETMSG = cRETMSG;
    }

    /* access modifiers changed from: 0000 */
    public String getC_STRICT_LEVEL() {
        return this.C_STRICT_LEVEL;
    }

    /* access modifiers changed from: 0000 */
    public void setC_STRICT_LEVEL(String cSTRICTLEVEL) {
        this.C_STRICT_LEVEL = cSTRICTLEVEL;
    }

    /* access modifiers changed from: 0000 */
    public String getC_SEND_INFORM() {
        return this.C_SEND_INFORM;
    }

    /* access modifiers changed from: 0000 */
    public void setC_SEND_INFORM(String cSENDINFORM) {
        this.C_SEND_INFORM = cSENDINFORM;
    }

    /* access modifiers changed from: 0000 */
    public String getC_CYCLE() {
        return this.C_CYCLE;
    }

    /* access modifiers changed from: 0000 */
    public void setC_CYCLE(String cCYCLE) {
        this.C_CYCLE = cCYCLE;
    }

    /* access modifiers changed from: 0000 */
    public Message_Ads copy() {
        Message_Ads copy = new Message_Ads();
        copy.C_HANDLER_URL = this.C_HANDLER_URL;
        copy.C_HANDLER = this.C_HANDLER;
        copy.C_HANDLER_APP_CODE = this.C_HANDLER_APP_CODE;
        copy.C_PAY_TYPE = this.C_PAY_TYPE;
        copy.C_AD_TYPE = this.C_AD_TYPE;
        copy.C_AD_SHAPE = this.C_AD_SHAPE;
        copy.C_SHAPE_INFO = this.C_SHAPE_INFO;
        copy.C_LINK = this.C_LINK;
        copy.C_CODE = this.C_CODE;
        copy.C_ID = this.C_ID;
        copy.C_TITLE = this.C_TITLE;
        copy.C_DESCRIPTION = this.C_DESCRIPTION;
        copy.C_IMG = this.C_IMG;
        copy.C_MARKET = this.C_MARKET;
        copy.C_COLOR = this.C_COLOR;
        copy.C_ISERIAL = this.C_ISERIAL;
        copy.C_RETCODE = this.C_RETCODE;
        copy.C_RETMSG = this.C_RETMSG;
        copy.C_STRICT_LEVEL = this.C_STRICT_LEVEL;
        copy.C_SEND_INFORM = this.C_SEND_INFORM;
        copy.C_CYCLE = this.C_CYCLE;
        return copy;
    }
}
