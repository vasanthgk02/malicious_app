package a.SurlyProjectFinal;

public final class R {

    public static final class attr {
        public static final int adtype = 2130771969;
        public static final int age = 2130771971;
        public static final int allowcall = 2130771976;
        public static final int appcode = 2130771968;
        public static final int dynamicReloadInterval = 2130771973;
        public static final int effect = 2130771975;
        public static final int gender = 2130771970;
        public static final int gps = 2130771974;
        public static final int reloadInterval = 2130771972;
    }

    public static final class color {
        public static final int black = 2131034112;
        public static final int red = 2131034113;
        public static final int transparency = 2131034114;
    }

    public static final class drawable {
        public static final int audacity = 2130837504;
        public static final int bg_control_h = 2130837505;
        public static final int btn_more = 2130837506;
        public static final int btn_pause_highlight = 2130837507;
        public static final int btn_pause_nor = 2130837508;
        public static final int btn_pause_press = 2130837509;
        public static final int btn_play_highlight = 2130837510;
        public static final int btn_play_list_nor = 2130837511;
        public static final int btn_play_list_press = 2130837512;
        public static final int btn_play_nor = 2130837513;
        public static final int btn_play_press = 2130837514;
        public static final int btn_playback_highlight = 2130837515;
        public static final int btn_playback_nor = 2130837516;
        public static final int btn_playback_press = 2130837517;
        public static final int btn_playnext_highlight = 2130837518;
        public static final int btn_playnext_nor = 2130837519;
        public static final int btn_playnext_press = 2130837520;
        public static final int de = 2130837521;
        public static final int folder_music = 2130837522;
        public static final int fx = 2130837523;
        public static final int fx2 = 2130837524;
        public static final int fx3 = 2130837525;
        public static final int guitar = 2130837526;
        public static final int guitar_hero = 2130837527;
        public static final int headphones = 2130837528;
        public static final int icon = 2130837529;
        public static final int intro = 2130837530;
        public static final int intro1 = 2130837531;
        public static final int intro_centar_image = 2130837532;
        public static final int mp3_list_background = 2130837533;
        public static final int mp3_list_cell_selector = 2130837534;
        public static final int next = 2130837535;
        public static final int pause = 2130837536;
        public static final int play_bg_control = 2130837537;
        public static final int player_pause_button_selector = 2130837538;
        public static final int player_play_button_selector = 2130837539;
        public static final int player_playback_button_selector = 2130837540;
        public static final int player_playnext_button_selector = 2130837541;
        public static final int prev = 2130837542;
        public static final int prog_bar = 2130837543;
        public static final int prog_bg = 2130837544;
        public static final int progcontrolball = 2130837545;
        public static final int progress_bar_video = 2130837546;
        public static final int start = 2130837547;
        public static final int stop = 2130837548;
        public static final int suli = 2130837549;
        public static final int suli10 = 2130837550;
        public static final int suli11 = 2130837551;
        public static final int suli12 = 2130837552;
        public static final int suli13 = 2130837553;
        public static final int suli14 = 2130837554;
        public static final int suli15 = 2130837555;
        public static final int suli16 = 2130837556;
        public static final int suli17 = 2130837557;
        public static final int suli18 = 2130837558;
        public static final int suli19 = 2130837559;
        public static final int suli2 = 2130837560;
        public static final int suli20 = 2130837561;
        public static final int suli21 = 2130837562;
        public static final int suli22 = 2130837563;
        public static final int suli3 = 2130837564;
        public static final int suli4 = 2130837565;
        public static final int suli5 = 2130837566;
        public static final int suli6 = 2130837567;
        public static final int suli7 = 2130837568;
        public static final int suli8 = 2130837569;
        public static final int suli9 = 2130837570;
        public static final int twitter05 = 2130837571;
    }

    public static final class id {
        public static final int FromIntroToMain = 2131230738;
        public static final int RelativeLayout1 = 2131230733;
        public static final int SecondaryProgress = 16842752;
        public static final int SeekBar = 2131230729;
        public static final int ad = 2131230721;
        public static final int audioCurrentFrameTime = 2131230730;
        public static final int audioForwardButton = 2131230728;
        public static final int audioPlayButton = 2131230726;
        public static final int audioPlayPauseButton = 2131230725;
        public static final int audioRewindButton = 2131230727;
        public static final int audioTotalDuration = 2131230731;
        public static final int chip_cell = 2131230741;
        public static final int controlOption = 2131230724;
        public static final int dialog_Message_textView = 2131230736;
        public static final int highlayout = 2131230720;
        public static final int introLayout = 2131230737;
        public static final int linearLayout1 = 2131230734;
        public static final int list = 2131230732;
        public static final int mp3_cell_detail_text = 2131230743;
        public static final int mp3_list_title = 2131230742;
        public static final int playerControls = 2131230723;
        public static final int progressBar2 = 2131230735;
        public static final int relativeLayout1 = 2131230740;
        public static final int text = 2131230722;
        public static final int text2 = 2131230739;
        public static final int widgetNext = 2131230747;
        public static final int widgetPlay = 2131230746;
        public static final int widgetPrev = 2131230745;
        public static final int widget_title = 2131230744;
    }

    public static final class layout {
        public static final int audio = 2130903040;
        public static final int dialog_activity = 2130903041;
        public static final int intro = 2130903042;
        public static final int mp3_list_cell = 2130903043;
        public static final int musicwidget = 2130903044;
    }

    public static final class string {
        public static final int app_name = 2131099649;
        public static final int hello = 2131099648;
        public static final int need_sdcard = 2131099650;
        public static final int no_file = 2131099651;
    }

    public static final class style {
        public static final int Theme_CustomDialog = 2131165185;
        public static final int style_dialog = 2131165184;
    }

    public static final class styleable {
        public static final int[] com_cauly_android_ad_AdView = {R.attr.appcode, R.attr.adtype, R.attr.gender, R.attr.age, R.attr.reloadInterval, R.attr.dynamicReloadInterval, R.attr.gps, R.attr.effect, R.attr.allowcall};
        public static final int com_cauly_android_ad_AdView_adtype = 1;
        public static final int com_cauly_android_ad_AdView_age = 3;
        public static final int com_cauly_android_ad_AdView_allowcall = 8;
        public static final int com_cauly_android_ad_AdView_appcode = 0;
        public static final int com_cauly_android_ad_AdView_dynamicReloadInterval = 5;
        public static final int com_cauly_android_ad_AdView_effect = 7;
        public static final int com_cauly_android_ad_AdView_gender = 2;
        public static final int com_cauly_android_ad_AdView_gps = 6;
        public static final int com_cauly_android_ad_AdView_reloadInterval = 4;
    }

    public static final class xml {
        public static final int widgetmanager = 2130968576;
    }
}
